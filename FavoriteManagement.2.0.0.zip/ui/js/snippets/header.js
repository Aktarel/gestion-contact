/**
 * Created by brian.rose on 1/26/2017.
 */

$(document).ready(function(){
	$.ajax({})
});
